#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
import actionlib
import tf2_ros
import tf2_geometry_msgs
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import PoseStamped, Point, Quaternion, Twist
from tf.transformations import quaternion_from_euler
import math
import numpy as np

class TaskController:
    def __init__(self):
        rospy.init_node('task_controller_node', anonymous=False)

        # TF2 Listener 用于坐标变换
        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer)

        # Action Client, 用于向move_base发送导航目标
        self.move_base_client = actionlib.SimpleActionClient('move_base', MoveBaseAction)
        rospy.loginfo("正在等待 move_base action 服务...")
        self.move_base_client.wait_for_server()
        rospy.loginfo("已连接到 move_base action 服务。")
        
        # Publisher, 用于在搜索时控制机器人旋转
        self.cmd_vel_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=1)

        # Subscriber, 用于接收LaserScan数据
        self.scan_sub = None # 将在需要时激活
        
        # 房间的搜索起始点, 这些坐标需要根据你的地图 `0114.yaml` 进行微调
        # 这些坐标是根据你提供的 `random_model_for_room.py` 中的范围估算的
        self.room_search_points = {
            'A': (0.5, 2.4, 0.0),   # (x, y, yaw)
            'B': (2.0, 2.4, 0.0),
            'C': (3.9, 2.4, 0.0),
        }
        
        # 搜索状态变量
        self.board_pose_in_map = None
        self.is_searching = False
        self.target_room = None
        
        # 雷达数据处理参数
        self.MIN_WALL_DISTANCE = 0.1  # 激光点到机器人的最小距离
        self.MAX_WALL_DISTANCE = 1.5  # 激光点到机器人的最大距离 (可调)
        self.MIN_BOARD_WIDTH = 0.4    # 板子的最小宽度 (根据实际模型调整)
        self.MAX_BOARD_WIDTH = 0.8    # 板子的最大宽度 (根据实际模型调整)
        self.LINE_FIT_TOLERANCE = 0.02 # RANSAC直线拟合的容忍度

    def navigate_to_goal(self, x, y, yaw):
        """导航到指定位姿"""
        goal = MoveBaseGoal()
        goal.target_pose.header.frame_id = "map"
        goal.target_pose.header.stamp = rospy.Time.now()
        
        goal.target_pose.pose.position.x = x
        goal.target_pose.pose.position.y = y
        
        q = quaternion_from_euler(0, 0, yaw)
        goal.target_pose.pose.orientation = Quaternion(*q)

        rospy.loginfo(f"正在导航到目标点: (x={x:.2f}, y={y:.2f}, yaw={yaw:.2f})")
        self.move_base_client.send_goal(goal)
        
        # 等待结果,可以设置超时
        success = self.move_base_client.wait_for_result(rospy.Duration(60)) 
        
        if success and self.move_base_client.get_state() == actionlib.GoalStatus.SUCCEEDED:
            rospy.loginfo("成功到达目标点。")
            return True
        else:
            rospy.logwarn("未能到达目标点。")
            self.move_base_client.cancel_goal()
            return False

    def scan_callback(self, msg):
        """处理LaserScan数据的回调函数"""
        if not self.is_searching:
            return

        # --- 核心算法: 从激光数据中寻找板子 ---
        # 1. 将激光数据从极坐标转为笛卡尔坐标
        points = []
        for i, distance in enumerate(msg.ranges):
            # 过滤无效点 (inf, nan) 和太近/太远的点
            if self.MIN_WALL_DISTANCE < distance < self.MAX_WALL_DISTANCE:
                angle = msg.angle_min + i * msg.angle_increment
                points.append([distance * math.cos(angle), distance * math.sin(angle)])

        if len(points) < 10: # 如果有效点太少，直接返回
            return

        points = np.array(points)

        # 2. RANSAC 算法拟合直线 (最稳健的方法)
        best_line_inliers = []
        for _ in range(50): # 迭代次数
            # 随机选两个点
            idx = np.random.choice(len(points), 2, replace=False)
            p1, p2 = points[idx]

            # 计算直线方程 Ax + By + C = 0
            A = p2[1] - p1[1]
            B = p1[0] - p2[0]
            C = -A * p1[0] - B * p1[1]
            norm = math.sqrt(A**2 + B**2)
            if norm == 0: continue
            
            # 计算所有点到直线的距离
            distances = np.abs(A * points[:, 0] + B * points[:, 1] + C) / norm
            inliers = points[distances < self.LINE_FIT_TOLERANCE]

            if len(inliers) > len(best_line_inliers):
                best_line_inliers = inliers

        # 3. 验证找到的直线是否是我们的板子
        if len(best_line_inliers) > 10: # 至少有10个点才算有效
            # 计算这条直线的宽度
            min_pt = np.min(best_line_inliers, axis=0)
            max_pt = np.max(best_line_inliers, axis=0)
            board_width = np.linalg.norm(max_pt - min_pt)
            
            rospy.loginfo_throttle(1, f"检测到直线段，宽度: {board_width:.2f}m, 内点数: {len(best_line_inliers)}")

            if self.MIN_BOARD_WIDTH < board_width < self.MAX_BOARD_WIDTH:
                rospy.loginfo("板子宽度符合要求！ 判定为目标板！")
                self.is_searching = False # 停止搜索
                self.stop_robot()
                
                # 4. 计算板子的位姿 (位置和方向) - 对应图3-2和3-3
                # 直线的中点作为板子的中心点 (在laser_frame下)
                center_point_laser = np.mean(best_line_inliers, axis=0)
                
                # 直线的方向向量
                line_vector = best_line_inliers[-1] - best_line_inliers[0]
                # 板子的法向量 (方向)
                # 注意: 法向量有两个方向，我们需要选择朝向机器人的那一个
                board_yaw_laser = math.atan2(line_vector[1], line_vector[0]) + math.pi / 2
                
                # 创建板子中心的 PoseStamped (在 laser_frame 下)
                board_pose_laser = PoseStamped()
                board_pose_laser.header.frame_id = msg.header.frame_id # "laser_frame"
                board_pose_laser.header.stamp = msg.header.stamp
                board_pose_laser.pose.position.x = center_point_laser[0]
                board_pose_laser.pose.position.y = center_point_laser[1]
                
                # 检查法线方向是否朝向机器人 (原点)
                # 如果(center_point . normal_vector) > 0, 说明法线背离原点, 需要反向
                normal_vector = (math.cos(board_yaw_laser), math.sin(board_yaw_laser))
                if np.dot(center_point_laser, normal_vector) > 0:
                    board_yaw_laser += math.pi
                    
                q = quaternion_from_euler(0, 0, board_yaw_laser)
                board_pose_laser.pose.orientation = Quaternion(*q)

                # 5. 将板子位姿变换到 map 坐标系
                try:
                    self.board_pose_in_map = self.tf_buffer.transform(board_pose_laser, 'map', timeout=rospy.Duration(1.0))
                    rospy.loginfo(f"成功计算出板子在map下的位姿: {self.board_pose_in_map.pose.position}")
                except (tf2_ros.LookupException, tf2_ros.ConnectivityException, tf2_ros.ExtrapolationException) as e:
                    rospy.logerr(f"坐标变换失败: {e}")
                    self.board_pose_in_map = None # 失败，重置
                    self.is_searching = True # 继续搜索

    def search_for_board(self):
        """在一个区域内搜索板子，通过原地旋转"""
        rospy.loginfo("开始搜索板子...")
        self.board_pose_in_map = None
        self.is_searching = True
        
        # 订阅激光数据
        self.scan_sub = rospy.Subscriber('/scan', LaserScan, self.scan_callback, queue_size=1)
        
        # 发布旋转指令
        twist = Twist()
        twist.angular.z = 0.5  # 旋转速度 (rad/s)
        
        rate = rospy.Rate(10)
        start_time = rospy.Time.now()
        
        # 旋转最多15秒 (超过一圈)
        while not rospy.is_shutdown() and (rospy.Time.now() - start_time) < rospy.Duration(15):
            if self.board_pose_in_map: # 如果回调函数找到了板子
                break
            self.cmd_vel_pub.publish(twist)
            rate.sleep()
        
        # 停止机器人并取消订阅
        self.stop_robot()
        self.scan_sub.unregister()
        
        if self.board_pose_in_map:
            rospy.loginfo("成功找到板子并计算出位姿。")
            return True
        else:
            rospy.logwarn("在此区域未找到板子。")
            return False

    def stop_robot(self):
        """发送停止指令"""
        self.cmd_vel_pub.publish(Twist())

    def approach_board(self):
        """计算停靠点并导航过去"""
        if not self.board_pose_in_map:
            rospy.logerr("没有板子位姿信息，无法靠近。")
            return False
        
        rospy.loginfo("正在计算30cm停靠点...")
        
        # 板子在map下的姿态角
        board_orientation = self.board_pose_in_map.pose.orientation
        board_yaw_map = math.atan2(2 * (board_orientation.w * board_orientation.z + board_orientation.x * board_orientation.y),
                                   1 - 2 * (board_orientation.y**2 + board_orientation.z**2))

        # 计算停靠点 (板子位置沿着其法线方向后退0.3米)
        # 这对应图 3-3 中的 (x-c*cosθ, y-c*sinθ)
        offset = 0.30 # 30cm
        goal_x = self.board_pose_in_map.pose.position.x - offset * math.cos(board_yaw_map)
        goal_y = self.board_pose_in_map.pose.position.y - offset * math.sin(board_yaw_map)
        
        # 停靠点的方向应该是朝向板子
        goal_yaw = board_yaw_map + math.pi
        # 规范化角度到 [-pi, pi]
        goal_yaw = (goal_yaw + math.pi) % (2 * math.pi) - math.pi

        # 执行最后的停靠导航
        return self.navigate_to_goal(goal_x, goal_y, goal_yaw)

    def run(self):
        """主执行逻辑"""
        for room_name, search_point in self.room_search_points.items():
            rospy.loginfo(f"===== 前往房间 {room_name} =====")
            self.target_room = room_name
            
            # 1. 导航到搜索区域
            if not self.navigate_to_goal(*search_point):
                rospy.logwarn(f"无法到达房间 {room_name} 的搜索点，跳过。")
                continue
            
            rospy.sleep(1) # 等待稳定
            
            # 2. 在区域内搜索板子
            if self.search_for_board():
                # 3. 靠近板子
                rospy.sleep(1)
                if self.approach_board():
                    rospy.loginfo(f"***** 仿真任务成功！目标货物位于 {self.target_room} 房间。 *****")
                    # 在这里可以添加发送结果给实体机器人的代码
                    break # 任务完成，跳出循环
                else:
                    rospy.logerr("靠近板子失败，继续搜索下一个房间。")
            else:
                rospy.logwarn(f"在房间 {room_name} 未找到目标，继续下一个房间。")
        
        rospy.loginfo("所有房间搜索完毕，导航回初始点。")
        # 这里假设初始点是 (0,0,0)，请根据实际情况修改
        self.navigate_to_goal(0.0, 0.0, 0.0)
        rospy.loginfo("任务流程结束。")

if __name__ == '__main__':
    try:
        controller = TaskController()
        controller.run()
    except rospy.ROSInterruptException:
        pass
